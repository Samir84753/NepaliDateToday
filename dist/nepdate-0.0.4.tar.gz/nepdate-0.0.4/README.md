# NepaliDateToday
CLI to get today's Nepali date

https://pypi.org/project/nepdate/

pip install nepdate

command: nepalidate